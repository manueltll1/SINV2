<template>
    <title>
   Seguro de Auto
  </title>
  <link crossorigin="anonymous" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" rel="stylesheet"/>
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css" rel="stylesheet"/>

  <div class="container">
   <div class="header">
    <img alt="Company Logo" height="50" src="https://storage.googleapis.com/a1aa/image/CJXgCpwXkYqcPlCtwuWwklhDCyeeBeJobWPDsooOsGGqmYXnA.jpg" width="100"/>
    <div>
     <div class="title">
      Seguro de Auto
     </div>
     <div class="subtitle">
      MULTICOTIZACIÓN
     </div>
    </div>
    <img alt="Car Icon" height="50" src="https://storage.googleapis.com/a1aa/image/MgOz9hI6p54pJNI2f4Z2Q90eFJVt5l8mErGgJwM0FDPYTsrTA.jpg" width="50"/>
   </div>
   <div class="client-info">
    <div class="info">
     <p>
      CLIENTE: MARIA GUILLERMINA CORONADO ONTIVEROS
     </p>
     <p>
      EDAD: 60     SEXO: Mujer     PERSONA: Física
     </p>
     <p>
      VEHÍCULO: 2019 - HONDA PILOT TOURING 5P V6 3.5L VP ABS BA QC AC R18 NAVI AUT
     </p>
     <p>
      CÓDIGO POSTAL: 98609
     </p>
     <p>
      FECHA: 28 Oct 24 11:26 AM     COTIZACIÓN: 1842
     </p>
     <p>
      VALOR: Comercial
     </p>
    </div>
   </div>
   <div class="coverage">
    <div class="table-responsive">
     <table class="table">
      <thead>
       <tr>
        <th>
         COBERTURAS
        </th>
        <th>
         COBERTURA AMPLIA
        </th>
        <th>
         COBERTURA 0 DEDUCIBLE
        </th>
       </tr>
      </thead>
      <tbody>
       <tr>
        <td>
         DAÑOS MATERIALES PERDIDA TOTAL
        </td>
        <td>
         VALOR COMERCIAL
        </td>
        <td>
         VALOR COMERCIAL +10%
        </td>
       </tr>
       <tr>
        <td>
         DEDUCIBLE
        </td>
        <td>
         5%
        </td>
        <td>
         0%
        </td>
       </tr>
       <tr>
        <td>
         DAÑOS MATERIALES PARCIALES
        </td>
        <td>
         REPARACIÓN
        </td>
        <td>
         REPARACIÓN
        </td>
       </tr>
       <tr>
        <td>
         DEDUCIBLE
        </td>
        <td>
         5%
        </td>
        <td>
         0%
        </td>
       </tr>
       <tr>
        <td>
         ROBO TOTAL
        </td>
        <td>
         VALOR COMERCIAL
        </td>
        <td>
         VALOR COMERCIAL +10%
        </td>
       </tr>
       <tr>
        <td>
         DEDUCIBLE
        </td>
        <td>
         10%
        </td>
        <td>
         5%
        </td>
       </tr>
       <tr>
        <td>
         CRISTALES
        </td>
        <td>
         AMPARADOS (Tú pagas 20% DE DEDUCIBLE)
        </td>
        <td>
         AMPARADOS (Tú pagas 20% DE DEDUCIBLE)
        </td>
       </tr>
       <tr>
        <td>
         GASTOS MÉDICOS OCUPANTES
        </td>
        <td>
         $1,000,000.00
        </td>
        <td>
         $1,000,000.00
        </td>
       </tr>
       <tr>
        <td>
         RC DAÑOS A TERCEROS
        </td>
        <td>
         $3,000,000.00
        </td>
        <td>
         $3,000,000.00
        </td>
       </tr>
       <tr>
        <td>
         RC ADICIONAL POR MUERTE DE TERCEROS
        </td>
        <td>
         $3,000,000.00
        </td>
        <td>
         $3,000,000.00
        </td>
       </tr>
       <tr>
        <td>
         RC DAÑOS A TERCEROS EN USA Y CANADÁ
        </td>
        <td>
         AMPARADA
        </td>
        <td>
         AMPARADA
        </td>
       </tr>
       <tr>
        <td>
         EXTENSIÓN DE RESPONSABILIDAD CIVIL
        </td>
        <td>
         AMPARADA
        </td>
        <td>
         AMPARADA
        </td>
       </tr>
       <tr>
        <td>
         MUERTE ACCIDENTAL DEL CONDUCTOR
        </td>
        <td>
         $100,000.00
        </td>
        <td>
         $100,000.00
        </td>
       </tr>
       <tr>
        <td>
         ASISTENCIA LEGAL
        </td>
        <td>
         AMPARADA
        </td>
        <td>
         AMPARADA
        </td>
       </tr>
       <tr>
        <td>
         ASISTENCIA VIAL
        </td>
        <td>
         AMPARADA
        </td>
        <td>
         AMPARADA
        </td>
       </tr>
      </tbody>
     </table>
    </div>
   </div>
   <div class="prices">
    <div class="table-responsive">
     <table class="table">
      <thead>
       <tr>
        <th>
         PRECIO NORMAL
        </th>
        <th>
         PAGO ANUAL
        </th>
        <th>
         PRECIO INV
        </th>
       </tr>
      </thead>
      <tbody>
       <tr>
        <td>
         COBERTURA AMPLIA
        </td>
        <td>
         COBERTURA 0 DEDUCIBLE
        </td>
        <td>
         COBERTURA AMPLIA
        </td>
        <td>
         COBERTURA 0 DEDUCIBLE
        </td>
       </tr>
       <tr>
        <td>
         $14,746.24
        </td>
        <td>
         $22,281.78
        </td>
        <td class="highlight">
         $11,924.59
        </td>
        <td class="highlight">
         $17,953.02
        </td>
       </tr>
       <tr>
        <td>
         $23,019.49
        </td>
        <td>
         $29,477.85
        </td>
        <td>
         $17,768.86
        </td>
        <td>
         $22,612.70
        </td>
       </tr>
       <tr>
        <td>
         $16,569.45
        </td>
        <td>
         $24,729.31
        </td>
        <td>
         $13,406.36
        </td>
        <td>
         $19,934.25
        </td>
       </tr>
       <tr>
        <td>
         ND
        </td>
        <td>
         ND
        </td>
        <td>
         $23,990.00
        </td>
        <td>
         ND
        </td>
       </tr>
       <tr>
        <td>
         $22,697.82
        </td>
        <td>
         $30,721.99
        </td>
        <td>
         $18,439.06
        </td>
        <td>
         $24,914.12
        </td>
       </tr>
      </tbody>
     </table>
    </div>
   </div>
   <div class="notes">
    <div class="note">
     <p>
      NOTAS IMPORTANTES:
     </p>
     <p>
      - Los precios tienen una validez de 7 días naturales, están sujetos a cambios por las aseguradoras sin previo aviso y pueden variar si se cambia la Descripción del Vehículo, Código Postal, Edad, etc.
     </p>
     <p>
      - La aplicación de cada una de las coberturas y deducibles se determinará en cada aseguradora y se encuentra descrita en las condiciones GENERALES. Pídela a tu Ejecutivo INV.
     </p>
     <p>
      - Complementa tu póliza con Coberturas Adicionales como: Robo Parcial, Llantas y Rines, Auto Sustituto, Extensión de RC, 0 Deducible en Robo, etc.
     </p>
     <p>
      - Valor Comercial: ANA, CHUBB, ALLIANZ, HDI: GUÍA EBC     QUALITAS: GUÍA CESVI VIN Plus
     </p>
    </div>
   </div>
   <div class="footer">
    <div class="contact">
     <p>
      <i class="fas fa-phone">
      </i>
      492 9241026
     </p>
     <p>
      <i class="fas fa-globe">
      </i>
      www.inv.mx
     </p>
    </div>
    <div class="social">
     <i class="fab fa-twitter">
     </i>
     @inviertotenseguros
    </div>
   </div>
  </div>

</template>

<style scoped>
   body {
            font-family: 'Arial', sans-serif;
            font-size: 14px;
        }
        .header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 20px;
        }
        .header img {
            height: 50px;
        }
        .header .title {
            font-size: 24px;
            font-weight: bold;
        }
        .header .subtitle {
            font-size: 18px;
            color: #666;
        }
        .client-info, .coverage, .prices, .notes {
            margin: 20px 0;
        }
        .client-info .info, .coverage .table, .prices .table, .notes .note {
            border: 1px solid #ccc;
            padding: 10px;
        }
        .coverage .table th, .coverage .table td, .prices .table th, .prices .table td {
            border: 1px solid #ccc;
            padding: 10px;
        }
        .prices .table th {
            background-color: #f8f8f8;
        }
        .prices .table .highlight {
            background-color: #ffeb3b;
        }
        .notes .note {
            font-size: 12px;
            color: #666;
        }
        .footer {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 20px;
            background-color: #f8f8f8;
        }
        .footer .contact {
            font-size: 12px;
        }
        .footer .social {
            font-size: 18px;
        }
  </style>